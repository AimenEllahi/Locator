// import "./App.css";
import Dealers from "./components/Dealers";

function App() {
  return (
    <div className="w-full h-[100vh]">
      <Dealers />
    </div>
  );
}

export default App;
